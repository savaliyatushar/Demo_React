// App.js
import React from "react";
import "./App.css";
import Navbar from "./components/Header/Navbar";
import "bootstrap/dist/css/bootstrap.min.css";
import Home from "./pages/Home/Home";
import Footer from "./components/Footer/Footer";
import { BrowserRouter as Router, Route, Routes} from "react-router-dom";
import Cart from "./pages/Cart/Cart";
import Login from "./pages/loginform/Login";
import Products from "./components/mobile-products/M-products-nav";
import About from "./pages/About/About";
import Blog from "./pages/Blog/Blog";

const App = () => {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/home" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/products" element={<Products />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/about" element={<About />} />
        <Route path="/blog" element={<Blog />} />
      </Routes>
      <Footer />
    </Router>
  );
};

export default App;
