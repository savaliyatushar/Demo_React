import React from "react";
import Blogs from "../../components/Blog/Blogs";
import Subscribes from "../../components/Subscribes/Subscribes";
import Instanav from "../../components/Insta/Insta-nav";

function Blog() {
  return (
    <>
      <div>
        <Blogs heading={"Blog"} />
      </div>
      <div>
        <Subscribes />
      </div>
      <div>
        <Instanav />
      </div>
    </>
  );
}

export default Blog;
