import React, { useEffect, useState } from "react";
import { Col, Container, Form, Row } from "react-bootstrap";
import axios from "axios";
import "./Login.css";
import Buttons from "../../components/Buttons/Button";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const saveuser = async () => {
   
    try {
      const response = await axios.post(
        "https://jsonplaceholder.typicode.com/posts",
        {
          email,
          password,   
        }
      );
      console.log(response.data);
      
    } catch (error) {
      console.error("There was an error logging in!", error);
     
    }
  };

  return (
    <Container
      fluid
      className="d-flex bg-watch bg-primary align-items-center justify-content-center min-vh-100"
    >
      <Row className="w-100">
        <Col xs={6} lg={7}></Col>
        <Col xs={6} md={6} lg={4} className="formjustify">
          <Form className="p-4 height width shadow-lg rounded bg-light">
            <div className="pt-3">
              <Form.Group controlId="formBasicEmail">
                <Form.Label className="border-danger-2">
                  Email address
                </Form.Label>
                <Form.Control
                  type="email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter email"
                />
              </Form.Group>
            </div>
            <div className="pt-3">
              <Form.Group controlId="formBasicPassword" className="mb-3">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  name="password"
                  placeholder="Password"
                />
              </Form.Group>
            </div>
            <Form.Text className="text-muted pt-0">
              <a href="/" className="text-decoration-none">
                Registration
              </a>
            </Form.Text>
            <div className="pt-4 text-center">
              <Buttons onClick={saveuser} button="Login" />
            </div>
           
           
           
          </Form>
        </Col>
      </Row>
    </Container>
  );
};

export default Login;
