import React from "react";
import { Navbar, Nav, Container, NavDropdown } from "react-bootstrap";
import { FaShoppingCart, FaUser } from "react-icons/fa";
import { IoSearch } from "react-icons/io5";
import "./Navbar.css";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const MyNavbar = () => {
  const itemCount = useSelector((state) => state.cart.itemCount);

  return (
    <Navbar expand="lg" fixed="top" className="bg-light">
      <Container>
        <Navbar.Brand href="/home">
          <img
            src="https://themewagon.github.io/MiniStore/images/main-logo.png"
            alt="Logo"
          />
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
          <Nav className="">
            <Nav.Link href="/home" className="me-4">
              Home
            </Nav.Link>
            <Nav.Link href="#services" className="me-4">
              SERVICES
            </Nav.Link>
            <Nav.Link href="#product" className="me-4">
              PRODUCTS
            </Nav.Link>
            <Nav.Link href="#watches" className="me-4">
              WATCHES
            </Nav.Link>
            <Nav.Link href="#sale" className="me-4">
              SALE
            </Nav.Link>
            <Nav.Link href="#blog" className="me-4">
              BLOG
            </Nav.Link>
            <NavDropdown title="PAGES" id="basic-nav-dropdown">
              <NavDropdown.Item href="/about">About</NavDropdown.Item>
              <NavDropdown.Item href="/blog">Blog</NavDropdown.Item>
              <NavDropdown.Item href="/">Shop</NavDropdown.Item>
              <NavDropdown.Item href="/cart">Cart</NavDropdown.Item>
              <NavDropdown.Item href="/">Checkout</NavDropdown.Item>
              <NavDropdown.Item href="/">Single Post</NavDropdown.Item>
              <NavDropdown.Item href="#contact">Contact</NavDropdown.Item>
            </NavDropdown>
          </Nav>

          <Nav className="align-items-center ">
            <Link to="/" className="me-4 text-dark">
              <IoSearch />
            </Link>
            <Link to="/login" className="me-4 text-dark">
              <FaUser />
            </Link>
            <Link to="/cart" className="me-2 text-dark text-decoration-none">
              <FaShoppingCart />
              <span className="cricle  text-white ">{itemCount}</span>
            </Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default MyNavbar;
