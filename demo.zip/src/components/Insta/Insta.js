import React from "react";
import { Col } from "react-bootstrap";

const Instapost = ({ post }) => {
  return (
    <>
      
        <Col className="">
          <img
            src={post}
            alt="Instagram Post"
            className="img"
            //   style={{ width: "210px", height: "300px", margin: "0", padding: "0" }}
          />
        </Col>
     
    </>
  );
};

export default Instapost;
