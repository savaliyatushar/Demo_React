export const list2 = [
  {
    id: 1,
    title: "PINK WATCH",
    price: "1100",
    img: "https://themewagon.github.io/MiniStore/images/product-item6.jpg",
  },
  {
    id: 2,
    title: "HEAVY WATCH",
    price: "1002",
    img: "https://themewagon.github.io/MiniStore/images/product-item7.jpg",
  },
  {
    id: 3,
    title: "BLACK WATCH",
    price: "2000",
    img: "	https://themewagon.github.io/MiniStore/images/product-item8.jpg",
  },
  {
    id: 4,
    title: "SPOTTED WATCH",
    price: "1052",
    img: "https://themewagon.github.io/MiniStore/images/product-item9.jpg",
  },
  {
    id: 5,
    title: "BLACK WATCH",
    price: "3002",
    img: "https://themewagon.github.io/MiniStore/images/product-item7.jpg",
  },
  {
    id: 6,
    title: "SPOTTED WATCH",
    price: "1500",
    img: "https://themewagon.github.io/MiniStore/images/product-item9.jpg",
  },
  {
    id: 7,
    title: "BLACK WATCH",
    price: "1202",
    img: "		https://themewagon.github.io/MiniStore/images/product-item10.jpg",
  },
  {
    id: 8,
    title: "SPOTTED WATCH",
    price: "1802",
    img: "https://themewagon.github.io/MiniStore/images/product-item8.jpg",
  },
];

export default list2;
