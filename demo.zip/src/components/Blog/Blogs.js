import React from 'react'
import { Link } from 'react-router-dom';

function Blogs({ heading }) {
  return (
    <>
      <section className="hero-section position-relative bg-light-blue padding-medium">
        <div className="hero-content">
          <div className="container">
            <div className="row">
              <div className="text-center padding-top no-padding-bottom">
                <h2 className="display-2 text-uppercase text-dark">
                  {heading}
                </h2>
                <span>
                  <Link to="/home" className=" text-decoration-none text-dark">
                    Home
                  </Link>
                  <span>/BLOG</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Blogs