export const list = [
  {
    id: 1,
    title: "i phone xr",
    price: "1100",
    img: "https://themewagon.github.io/MiniStore/images/product-item1.jpg",
  },
  {
    id: 2,
    title: "i phone 11",
    price: "1002",
    img: "https://themewagon.github.io/MiniStore/images/product-item2.jpg",
  },
  {
    id: 3,
    title: "i phone 13",
    price: "2000",
    img: "https://themewagon.github.io/MiniStore/images/product-item4.jpg",
  },
  {
    id: 4,
    title: "i phone 12",
    price: "1052",
    img: "https://themewagon.github.io/MiniStore/images/product-item5.jpg",
  },
  {
    id: 5,
    title: "i phone 14",
    price: "3002",
    img: "https://themewagon.github.io/MiniStore/images/product-item4.jpg",
  },
  {
    id: 6,
    title: "i phone 14",
    price: "1500",
    img: "https://themewagon.github.io/MiniStore/images/product-item3.jpg",
  },
  {
    id: 7,
    title: "i phone 15",
    price: "1202",
    img: "	https://themewagon.github.io/MiniStore/images/product-item1.jpg",
  },
  {
    id: 8,
    title: "i phone 16",
    price: "1802",
    img: "https://themewagon.github.io/MiniStore/images/product-item2.jpg",
  },
];

export default list;
